// // backend/helpers/cookies.js
// function computeCookieOptions(req) {
//   // detect HTTPS even behind proxies (CloudFront/ALB/Nginx)
//   const forwardedProto = (req.headers["x-forwarded-proto"] || "").toLowerCase();
//   const isHttps = req.secure || forwardedProto === "https";

//   const COOKIE_DOMAIN = process.env.COOKIE_DOMAIN || undefined;
//   const host = (req.headers.host || "").split(":")[0].toLowerCase(); // strip port
//   const canUseDomain =
//     COOKIE_DOMAIN &&
//     host &&
//     (host === COOKIE_DOMAIN.replace(/^\./, "") || host.endsWith(COOKIE_DOMAIN));

//   return {
//     httpOnly: true,
//     secure: !!isHttps,                    // true only if HTTPS
//     sameSite: isHttps ? "none" : "lax",   // None on HTTPS, Lax on HTTP (localhost)
//     domain: canUseDomain ? COOKIE_DOMAIN : undefined, // only if host matches your domain
//     path: "/api/auth",                    // covers /api/auth/refresh
//     maxAge: 30 * 24 * 60 * 60 * 1000,     // 30d
//   };
// }

// function setRefreshCookie(req, res, refreshToken) {
//   const opts = computeCookieOptions(req);
//   res.cookie("refreshToken", refreshToken, opts);
// }

// function clearRefreshCookie(req, res) {
//   const opts = computeCookieOptions(req);
//   opts.maxAge = 0;
//   res.cookie("refreshToken", "", opts);
// }

// module.exports = { setRefreshCookie, clearRefreshCookie };




// backend/helpers/cookies.js

// function computeCookieOptions(req) {
//   // Detect HTTPS robustly behind API Gateway/CloudFront
//   const host = (req.headers.host || "").split(":")[0].toLowerCase();
//   const forwardedProto = String(req.headers["x-forwarded-proto"] || "").toLowerCase();

//   // Treat execute-api / edzest.org hosts as HTTPS too (defensive)
//   const probablyHttps =
//     forwardedProto === "https" ||
//     req.secure === true ||
//     host.endsWith(".amazonaws.com") ||
//     host.endsWith(".edzest.org");

//   const COOKIE_DOMAIN = process.env.COOKIE_DOMAIN || undefined;
//   const bare = COOKIE_DOMAIN ? COOKIE_DOMAIN.replace(/^\./, "").toLowerCase() : undefined;

//   // Only set Domain if current host matches your site domain
//   const canUseDomain =
//     !!COOKIE_DOMAIN &&
//     !!host &&
//     (host === bare || (bare && host.endsWith("." + bare)));

//   return {
//     httpOnly: true,
//     secure: !!probablyHttps,                 // required for SameSite=None
//     sameSite: probablyHttps ? "none" : "lax",
//     domain: canUseDomain ? COOKIE_DOMAIN : undefined,
//     path: "/api/auth",                       // covers /api/auth/refresh (kept same)
//     maxAge: 30 * 24 * 60 * 60 * 1000,        // 30d
//   };
// }

// function setRefreshCookie(req, res, refreshToken) {
//   const opts = computeCookieOptions(req);
//   res.cookie("refreshToken", refreshToken, opts);
// }

// function clearRefreshCookie(req, res) {
//   // Use clearCookie with matching attributes so the browser actually removes it
//   const opts = computeCookieOptions(req);
//   res.clearCookie("refreshToken", {
//     ...opts,
//     // clearCookie ignores maxAge; ensure an explicit expiry in the past
//     expires: new Date(0),
//   });
// }

// module.exports = { setRefreshCookie, clearRefreshCookie };

// backend/helpers/cookies.js
function computeCookieOptions(req) {
  const host = (req.headers.host || "").split(":")[0].toLowerCase();
  const forwardedProto = String(req.headers["x-forwarded-proto"] || "").toLowerCase();

  // Treat execute-api / edzest.org hosts as HTTPS too (defensive)
  const probablyHttps =
    forwardedProto === "https" ||
    req.secure === true ||
    host.endsWith(".amazonaws.com") ||
    host.endsWith(".edzest.org");

  const COOKIE_DOMAIN = process.env.COOKIE_DOMAIN || undefined;
  const bare = COOKIE_DOMAIN ? COOKIE_DOMAIN.replace(/^\./, "").toLowerCase() : undefined;

  // Only set Domain if current host matches your site domain
  const canUseDomain =
    !!COOKIE_DOMAIN &&
    !!host &&
    (host === bare || (bare && host.endsWith("." + bare)));

  return {
    httpOnly: true,
    secure: !!probablyHttps,                // required with SameSite=None
    sameSite: probablyHttps ? "none" : "lax",
    domain: canUseDomain ? COOKIE_DOMAIN : undefined,
    path: "/",                              // <- key so cookie is sent back on your APIGW path
    maxAge: 30 * 24 * 60 * 60 * 1000,       // 30d
  };
}

function setRefreshCookie(req, res, refreshToken) {
  const opts = computeCookieOptions(req);
  res.cookie("refreshToken", refreshToken, opts);
}

function clearRefreshCookie(req, res) {
  const opts = computeCookieOptions(req);
  res.clearCookie("refreshToken", { ...opts, expires: new Date(0) });
}

module.exports = { setRefreshCookie, clearRefreshCookie };
