const express = require("express");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand, GetCommand } = require("@aws-sdk/lib-dynamodb");


const router = express.Router();
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));

const PAYMENTS = process.env.PAYMENTS_TABLE;
const QBANK = process.env.QBANK_TABLE;

// Razorpay instance
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

// helper
const now = () => new Date().toISOString();

// ✅ Create order
console.log("✅ Payments route file loaded");
router.post("/create-order", async (req, res) => {
   console.log("🟢 /create-order route hit!");
  try {
    const amount = parseInt(process.env.QBANK_PRICE_PAISE);
    const receipt = `order_${Date.now()}`;

    const order = await razorpay.orders.create({
      amount,
      currency: "INR",
      receipt,
    });

    // Save initial record
    await ddb.send(new PutCommand({
      TableName: PAYMENTS,
      Item: {
        paymentId: `pending_${order.id}`,
        orderId: order.id,
        amountPaise: amount,
        currency: "INR",
        status: "CREATED",
        createdAt: now(),
        updatedAt: now(),
      },
    }));

    res.json({
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      key: process.env.RAZORPAY_KEY_ID,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create order" });
  }
});

// ✅ Verify payment
router.post("/verify-payment", async (req, res) => {
  try {
    const { order_id, payment_id, signature, userId } = req.body;

    const hmac = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET);
    hmac.update(`${order_id}|${payment_id}`);
    const digest = hmac.digest("hex");

    if (digest !== signature) {
      return res.status(400).json({ error: "Invalid signature" });
    }

    // Store verified payment
    await ddb.send(new PutCommand({
      TableName: PAYMENTS,
      Item: {
        paymentId: payment_id,
        orderId: order_id,
        userId,
        amountPaise: parseInt(process.env.QBANK_PRICE_PAISE),
        currency: "INR",
        status: "SUCCESS",
        signatureVerified: true,
        createdAt: now(),
        updatedAt: now(),
      },
    }));

    router.get("/test", (req, res) => res.json({ msg: "Payments route works!" }));


    // Unlock Q-Bank (30-day access)
    const accessFrom = new Date();
    const accessTill = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    await ddb.send(new PutCommand({
      TableName: QBANK,
      Item: {
        userId,
        productId: process.env.QBANK_PRODUCT_ID,
        accessFrom: accessFrom.toISOString(),
        accessTill: accessTill.toISOString(),
        sourcePaymentId: payment_id,
        status: "ACTIVE",
      },
    }));

    res.json({ success: true, message: "Payment verified & access granted" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Verification failed" });
  }
});

module.exports = router;
