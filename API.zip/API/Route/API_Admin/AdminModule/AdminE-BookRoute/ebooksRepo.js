const { v4: uuidv4 } = require("uuid");

// ------------------ Using global v3 Dynamo wrapper ------------------
const {
  ddb,
  GetCommand,
  PutCommand,
  UpdateCommand,
  QueryCommand,
} = require("../../../../Services/aws/dynamo");

const TABLE = process.env.DDB_EBOOKS || "e-book";
const GSI_DATE = "byInstituteDate";
const GSI_SLUG = "byInstituteSlug";

/* ============================================================
   ✅ Create E-Book (same logic, v3 client)
============================================================ */
async function createEBook(item) {
  if (!item.ebookid) item.ebookid = uuidv4();

  await ddb.send(
    new PutCommand({
      TableName: TABLE,
      Item: item,
      ConditionExpression: "attribute_not_exists(ebookid)",
    })
  );

  return item;
}

/* ============================================================
   ✅ Get by ID
============================================================ */
async function getById(ebookid) {
  const out = await ddb.send(
    new GetCommand({
      TableName: TABLE,
      Key: { ebookid },
    })
  );
  return out.Item || null;
}

/* ============================================================
   ✅ Get by Institute + Slug (GSI query)
============================================================ */
async function getByInstituteAndSlug(instituteId, slug) {
  const out = await ddd.send(
    new QueryCommand({
      TableName: TABLE,
      IndexName: GSI_SLUG,
      KeyConditionExpression: "instituteId = :i AND #slug = :s",
      ExpressionAttributeValues: {
        ":i": instituteId,
        ":s": slug,
      },
      ExpressionAttributeNames: {
        "#slug": "slug",
      },
      Limit: 1,
    })
  );

  return out.Items?.[0] || null;
}

/* ============================================================
   ✅ List all by institute (GSI + cursor)
============================================================ */
async function listByInstitute(instituteId, opts = {}) {
  const { status, limit = 20, cursor, descending = true } = opts;

  const params = {
    TableName: TABLE,
    IndexName: GSI_DATE,
    KeyConditionExpression: "instituteId = :i",
    ExpressionAttributeValues: { ":i": instituteId },
    ScanIndexForward: !descending,
    Limit: limit,
  };

  if (cursor) params.ExclusiveStartKey = cursor;

  if (status) {
    params.FilterExpression = "#status = :s";
    params.ExpressionAttributeNames = { "#status": "status" };
    params.ExpressionAttributeValues[":s"] = status;
  }

  const out = await ddb.send(new QueryCommand(params));

  return {
    items: out.Items || [],
    cursor: out.LastEvaluatedKey || null,
  };
}

/* ============================================================
   ✅ Update only provided fields (dynamic)
============================================================ */
async function updateEBook(ebookid, patch = {}) {
  const fields = [
    "title",
    "slug",
    "coverImage",
    "chapters",
    "tags",
    "status",
    "authorId",
    "instituteId",
    "meta",
  ];

  const names = {};
  const values = {};
  const sets = [];

  for (const key of fields) {
    if (patch[key] !== undefined) {
      names[`#${key}`] = key;
      values[`:${key}`] = patch[key];
      sets.push(`#${key} = :${key}`);
    }
  }

  // Always update updatedAt
  names["#updatedAt"] = "updatedAt";
  values[":updatedAt"] = new Date().toISOString();
  sets.push("#updatedAt = :updatedAt");

  if (!sets.length) return await getById(ebookid);

  const params = {
    TableName: TABLE,
    Key: { ebookid },
    UpdateExpression: `SET ${sets.join(", ")}`,
    ExpressionAttributeNames: names,
    ExpressionAttributeValues: values,
    ReturnValues: "ALL_NEW",
  };

  const out = await ddb.send(new UpdateCommand(params));
  return out.Attributes;
}

module.exports = {
  createEBook,
  getById,
  getByInstituteAndSlug,
  listByInstitute,
  updateEBook,
};
